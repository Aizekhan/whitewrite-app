# Наші анімації (`Animations/Own/`): аудит і база

Тут лежать **лише** кліпи, зроблені нами з власних поз (`LICENSE.md`). Їх можна віддавати користувачам WhiteWrite.
Кліпи Mixamo, Quaternius і Meshy лежать поруч, у `Animations/<Бібліотека>/`, і в цю теку не потрапляють.

- База: `manifest.json` (`schema: artpipeline.anims/1`), 119 кліпів каталогу, **усі 119 зроблено**.
- Джерело даних: каталог станів у `Blender/own_pack.py`, самі рухи (пози) у `Blender/own_clips.py`.
- Галерея для перегляду: `gallery.html` (усі кліпи за категоріями, рух при наведенні).
- Під кожен тип тіла: `Base/Types/<тип>/<clip>.glb` — той самий кліп, розв'язаний на тілі цього типу (ступні на його підлозі, руки не в животі), для браузера. У Unity досить спільних FBX (Humanoid).
- Кліпи: `Base/<clip>.fbx` (тільки скелет, Humanoid) і `Base/<clip>.glb` (з манекеном, для браузера).
- Прев'ю: `Base/Previews/<clip>.webp` — рухома мініатюра 256 px, петля 1–2 с, грає при наведенні.
  Поруч лежать `<clip>_poster.webp` (статичний кадр), `<clip>.mp4` (повне відео) і `retarget_<clip>.png` (усі 8 типів).
- Походження: `Base/Provenance/<clip>.json` (див. `PROVENANCE.md`).

```
B=E:/Tools/Blender/blender.exe
"$B" -b -P Blender/own_anims.py -- [clip ...]      # кліпи + кадри + mp4 + журнал
"$B" -b -P Blender/own_retarget.py -- [clip ...]   # перевірка на 8 типах
python Blender/own_pack.py                          # manifest.json, мініатюри, листи ретаргету
```

## Домовленості (для кожного кліпу в маніфесті)
| Поле | Правило |
|---|---|
| `root_motion` | завжди `false`: кліпи на місці. Тіло рухає гра (RPG Framework сам веде швидкість). `speed` (м/с) — поріг для blend tree, щоб ступні не ковзали; `travel` (м) — скільки гра має зсунути тіло (ухилення). |
| `loop` | `true` для станів (idle, walk, block, aim...), `false` для дій. Петля закінчується тією самою позою, з якої почалась. |
| `mirror_of` | дзеркальна пара (left/right): робимо окремим кліпом, бо браузер не вміє дзеркалити Humanoid. У Unity можна й галочкою Mirror. Атаки пишемо під праву руку; ліворукий варіант = дзеркало. |
| `active` | вікно удару 0..1 для атак → `AttackAsset` Active Start / Active End. |
| `framework` | який параметр Animator фреймворку вмикає стан. |
| `transitions` | куди і за якої умови стан переходить. |
| `retarget` | результат перевірки на кожному з 8 типів. |
| `prio` | 1 — мінімум для гри на фреймворку (26 кліпів), 2 — повний бій, 3 — розширення. |

## Звірка з RPG Framework (`D:\RPG-Framework`, лише читав)
Стани й параметри названі так само, як їх ставлять мости фреймворку:

| Міст | Параметр | Стан у нас |
|---|---|---|
| EnemyAnimatorBridge | `Speed`, `MoveX`, `MoveY` (float, м/с) | Locomotion (blend tree: idle 0 → walk 1.35 → run 3.4 → sprint 5.5; стрейфи за MoveX/MoveY) |
| | `Notice` (trigger) | notice |
| | `Death` + `DeathIndex` (int) | death_1..3 (DeathIndex 0..2) |
| CombatAnimatorBridge | `Attack` або власний тригер атаки | `<style>_attack_1..3`, `_attack_heavy` |
| | `ChargeHold` (bool), `ChargeRelease` (trigger) | `_charge` / `_charge_release`, `bow_draw/aim/release`, `magic_cast_charge/release` |
| | `Block` (bool), удар під час блоку | `_block` (петля), `_block_hit` |
| | `Parry`, `ParrySuccess`, `Opened` | `_parry`, `_parry_success`, `opened` |
| | `Dodge` | dodge_back / forward / left / right (напрям за MoveX/MoveY) |
| | `HitReact` + `HitLight` / `HitHeavy` / `Knockdown` | hit_light_*, hit_heavy, knockdown → knockdown_lie → get_up |
| | `AttackPace` (float) | множник швидкості станів атак: кліп не перероблюємо |

**Чого у фреймворку немає:** стрибка й падіння (`jump_start`, `fall`, `land`), присідання, сидіння, взаємодії та
жестів. У маніфесті вони позначені `"game"`: параметр задає сама гра (наприклад `Grounded`, `VerticalSpeed`).

## Стани й переходи (шаблон Animator)
```
Base layer
  Locomotion (blend Speed/MoveX/MoveY) ──weapon drawn──> Combat (<style>_idle + той самий blend)
  Combat ──Attack──> attack_1 ──Attack у вікні──> attack_2 ──> attack_3 ──end──> Combat
         ──ChargeHold──> charge (петля) ──ChargeRelease──> charge_release ──> Combat
         ──Block=true──> block (петля) ──удар──> block_hit ──> block;  Block=false ──> Combat
         ──Parry──> parry ──ParrySuccess──> parry_success ──> Combat
  Any State ──Dodge──> dodge_<dir> ──> Combat
  Any State ──HitLight/HitHeavy──> hit_* ──> Combat;  ──Knockdown──> knockdown ──> lie ──> get_up ──> Combat
  Any State ──Opened──> opened ──> Combat
  Any State ──Death (DeathIndex)──> death_N (кінець, тримає позу)
  Any State ──Notice──> notice ──> Combat
  Air (гра): jump_start ──> fall (петля) ──grounded──> land ──> Locomotion
Tail layer (лише ratfolk, Avatar Mask Tail1..6): tail_idle / tail_move / tail_alert
```

## Що в каталозі (категорії)
| Категорія | Кліпів | Що |
|---|---|---|
| locomotion | 16 | idle (+ варіанти look / tired), walk, walk_back, стрейфи, run, run_back, sprint, повороти, присід |
| air | 3 | стрибок, падіння, приземлення |
| combat_unarmed, _sword_shield, _one_hand, _two_hand, _dagger, _spear | 7–11 на стиль | стійка, комбо з 3 ударів, важкий, заряд, блок, удар у блок, парирування |
| combat_bow | 5 | стійка, натяг, прицілювання, постріл, швидкий постріл |
| combat_magic | 6 | стійка, швидке закляття, заряд і випуск, канал, удар по площі |
| dodge | 4 | назад, вперед (перекид), вліво, вправо |
| reaction / death | 13 | легкі удари з 4 боків, важкий, «відкритий», збиття → лежить → підйом, помітив, 3 смерті |
| interaction / social | 11 | взаємодія, підняти, двері, зілля, розмова, помах, радість, вказати, сісти |
| tail | 3 | хвіст крисолюда (окремий шар) |

**Варіативність:**
- `variant_of`: кілька кліпів на один стан, гра чергує їх випадково (idle → idle_look).
- `DeathIndex`: кілька смертей.
- Комбо: різні удари поспіль.
- Тип тіла: статура спершу тягне спільні кліпи через ретаргет. Де цього мало, той самий генератор робить
  варіант під тип з іншими числами (важка хода огра й орка, згорблена гобліна й крисолюда). Числа руху — це
  лише параметри, тому варіант коштує кілька рядків.

## Ретаргет на 8 типах (`Previews/retarget_*.png`, `retarget.json`)
Спільні FBX, перенесені Humanoid-способом (ті самі повороти, зсув таза за висотою таза), перевірено на всіх 8 типах
для кожного кліпу (найнижча точка тіла через кожні 3 кадри; падіння й лежання не рахуються):
| Тип | Кліпів, де ступня заходить у підлогу > 1 см | Найгірше |
|---|---|---|
| human_male, human_female, elf | 0 | 0 |
| orc | 0 | 0,7 см |
| goblin | 2 | 1,6 см |
| dwarf | 14 | 2,7 см |
| ogre | 12 | 2,5 см |
| ratfolk | 12 | 3,6 см |

- У Unity це прибирає **Foot IK** у станах Animator (галочка в стані) — раджу вмикати для гнома, огра, крисолюда.
- Для браузера/WhiteWrite є версії під тип (`Base/Types/<тип>/`): там ступні на підлозі точно, бо кліп розв'язано на тому тілі.
- Хвіст крисолюда в загальних кліпах не рухається; для нього окремий шар `tail_idle` / `tail_move` / `tail_alert`.

## Зброя в прев'ю
Мініатюри показують манекен із простими заглушками нашої форми (меч, щит, молот, кинджал, спис, посох, лук), щоб
було видно хват. У файли кліпів (FBX/GLB) зброя не входить: тримання — це кисть на кістці `RightHand` (`LeftHand`
для лука й щита); зброя кріпиться до кисті так, щоб клинок ішов з кулака з боку великого пальця.
Під наші предмети: одноручна — RustfangSword / RustcleaverAxe / SkullcrusherTotem / FrostAxe; щит — OrcWarshield;
дворучна — FrostHammer; кинджал — BloodfangDagger / ArcaneSkullblade; спис — BloodfeatherSpear / BloodfangTotemSpear;
посох — SkullshardWarstaff; лук — Bow / WarbornHornbow.

## Зроблено (2026-11-06)
119 кліпів: пересування 16, повітря 3, бій без зброї 13, меч+щит 9, одноручна 9, дворучна 11, кинджал 7, спис 11,
лук 5, магія 6, ухилення 4, реакції/смерті 13, взаємодія/жести 11, хвіст 3. Кожен — FBX (скелет, Humanoid), GLB (манекен),
GLB на кожному з 8 типів, рухома мініатюра, запис походження. Довжини, петлі, вікна ударів і параметри фреймворку — у
`manifest.json`.

**Що ще слабке (перша версія з поз):** рух чистий, але простіший за motion capture; пальці гнуться всі разом (вказівний
жест без окремого пальця); сидіння без стільця в прев'ю; перекид і падіння — найумовніші. Поправки — числами в `own_clips.py`.
