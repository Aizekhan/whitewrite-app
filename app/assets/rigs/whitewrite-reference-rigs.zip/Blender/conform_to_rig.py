"""Fit a character (or a piece of gear) to a reference rig, so it shares that rig's bones, rest pose and lengths.

    blender -b -P Blender/conform_to_rig.py -- <src.fbx|.glb> <type> <out_dir> <id>
            [--weights own|body] [--keys] [--keep-shape] [--preview] [--rigs <dir>]

<type>: a reference rig (built by ref_rigs.py): human_male, human_female, goblin, dwarf, ogre, elf, orc, ratfolk.
--rigs <dir>: the folder holding <type>/<type>.blend; without it the `Rigs` folder beside this script's folder
  (<script dir>/../Rigs, as in the WhiteWrite package), else D:/ArtPipeline/Characters/Rigs.

A rigged source (Meshy SmartRig / Mixamo, `mixamorig:*`; other bones are matched by role where they can be):
1. every source bone is laid onto the reference bone of the same role: its head onto the reference head, turned
   to the reference direction and stretched to the reference length; each vertex follows its own weights, so the
   mesh is carried onto the reference proportions (the mesh is fitted to the rig, never the other way round);
   fingers named otherwise (Meshy's Bone_0xx) are matched to the reference fingers by where they lie;
2. weights: `own` (default for a rigged source) keeps the source's weights, renamed to the reference bones (bones
   with no match hand theirs to the nearest matched parent); `body` takes them from the reference body
   (Data Transfer, nearest face), as for armour and clothes;
3. it is bound to the reference skeleton itself (its rest = the reference rest), clips dropped (they come from the
   animation packs through Humanoid).
An unrigged source (armour modelled on the reference body): left where it is, weights from the body (`body`).
--keys: the reference body's shape keys (Thin / Heavy / Muscular) carried onto the mesh (Surface Deform), so
  SetBlendShapeWeight on the body and on each piece of gear moves them together.
--keep-shape: only scale to the reference height, no per-bone fit (for a unique hero; the result is then NOT on
  the reference proportions, it only gets the reference names). Not for modular gear.
Textures: every image of the materials to <out_dir>/Textures/<id>_<kind>.png, at most 2048.
Out: <out_dir>/<id>.fbx, <id>.glb (the same, textures inside, for a browser), <id>.rig.json (schema
artpipeline.rig/1: body type, skeleton id, height, bones found / missing, triangles, shape keys, weights, source), and with --preview <out_dir>/Previews/<id>_conform.png (source | fitted | over the
reference body | a test pose).

"""
import bpy
import json
import os
import sys
from mathutils import Vector, Matrix

RIGS_HOME = "D:/ArtPipeline/Characters/Rigs"


def rigs_dir(args):
    if "--rigs" in args:
        return os.path.abspath(args[args.index("--rigs") + 1])
    near = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "Rigs"))
    return near if os.path.isdir(near) else RIGS_HOME
P = "mixamorig:"
MAX_TEX = 2048
FINGERS = ("Thumb", "Index", "Middle", "Ring", "Pinky")


def base(name):
    return name.split(":")[-1]


def load_rig(rigs, rtype):
    path = os.path.join(rigs, rtype, rtype + ".blend")
    if not os.path.exists(path):
        sys.exit(f"no reference rig {path}")
    with bpy.data.libraries.load(path) as (src, dst):
        dst.objects = list(src.objects)
    for o in dst.objects:
        bpy.context.collection.objects.link(o)
    arm = next(o for o in dst.objects if o.type == 'ARMATURE')
    body = next(o for o in dst.objects if o.type == 'MESH')
    return arm, body


def import_any(path):
    before = set(bpy.data.objects)
    if path.lower().endswith((".glb", ".gltf")):
        bpy.ops.import_scene.gltf(filepath=path)
    else:
        bpy.ops.import_scene.fbx(filepath=path)
    return [o for o in bpy.data.objects if o not in before]


def rest(arm):
    """bone name -> (head, tail) in world space, rest pose"""
    mw = arm.matrix_world
    return {b.name: (mw @ b.head_local, mw @ b.tail_local) for b in arm.data.bones}


def map_bones(src_arm, ref_arm, ref_rest, src_rest):
    """source bone -> reference bone (same Mixamo role); fingers by place when their names do not say"""
    ref_by_base = {base(b.name): b.name for b in ref_arm.data.bones}
    m = {}
    for b in src_arm.data.bones:
        r = ref_by_base.get(base(b.name))
        if r:
            m[b.name] = r
    for side in ("Left", "Right"):
        hand = next((s for s, r in m.items() if r == P + side + "Hand"), None)
        fore = next((s for s, r in m.items() if r == P + side + "ForeArm"), None)
        if fore and (not hand or len(src_arm.data.bones[hand].children) < 4):
            # Meshy sometimes hangs the real hand (the bone with the fingers) beside "Hand" under the forearm
            real = max(src_arm.data.bones[fore].children, key=lambda c: len(c.children), default=None)
            if real and len(real.children) >= 4 and real.name != hand:
                if hand:
                    del m[hand]
                hand = real.name
                m[hand] = P + side + "Hand"
        if not hand:
            continue
        missing = [P + f"{side}Hand{f}1" for f in FINGERS if P + f"{side}Hand{f}1" not in m.values()]
        if not missing:
            continue
        sh = src_arm.data.bones[hand]
        roots = [c for c in sh.children if c.name not in m]
        # put each root's place in the reference hand's frame: offset from the hand, scaled by the hands' lengths
        s_len = max(1e-4, (src_rest[hand][1] - src_rest[hand][0]).length)
        r_len = max(1e-4, (ref_rest[P + side + "Hand"][1] - ref_rest[P + side + "Hand"][0]).length)
        rot = (src_rest[hand][1] - src_rest[hand][0]).rotation_difference(
            ref_rest[P + side + "Hand"][1] - ref_rest[P + side + "Hand"][0])
        pairs = []
        for c in roots:
            p = ref_rest[P + side + "Hand"][0] + rot @ (src_rest[c.name][0] - src_rest[hand][0]) * (r_len / s_len)
            for rf in missing:
                pairs.append(((p - ref_rest[rf][0]).length, c, rf))
        used_c, used_r = set(), set()
        for _, c, rf in sorted(pairs, key=lambda x: x[0]):
            if c.name in used_c or rf in used_r:
                continue
            used_c.add(c.name)
            used_r.add(rf)
            chain, b = [], c
            while b and len(chain) < 4:
                chain.append(b)
                b = b.children[0] if len(b.children) == 1 else None
            for i, cb in enumerate(chain):
                m[cb.name] = rf[:-1] + str(i + 1)
    return m


def nearest_mapped(bone, m):
    b = bone
    while b is not None and b.name not in m:
        b = b.parent
    return m[b.name] if b is not None else P + "Hips"


def bone_dirs(arm, rest_pos, names_ok):
    """bone -> (head, direction vector to the next joint in its chain)"""
    out = {}
    for b in arm.data.bones:
        h, t = rest_pos[b.name]
        kids = [c for c in b.children if c.name in names_ok]
        # Mixamo chains: hips -> spine, spine2 -> neck, hand -> middle finger, foot -> toe
        pref = {"Hips": "Spine", "Spine2": "Neck", "LeftHand": "LeftHandMiddle1", "RightHand": "RightHandMiddle1",
                "LeftFoot": "LeftToeBase", "RightFoot": "RightToeBase"}.get(base(b.name))
        k = next((c for c in kids if base(names_ok[c.name]) == pref), None) if pref else \
            (kids[0] if len(kids) == 1 else None)
        out[b.name] = (h, (rest_pos[k.name][0] - h) if k else (t - h))
    return out


def fit_matrices(src_arm, ref_arm, m, src_rest, ref_rest, ground):
    """reference bone -> matrix taking the source bone's space onto the reference bone; the feet also squashed or
    stretched upright so the source's soles (at `ground`) land on the floor"""
    ident = {n: n for n in ref_rest}
    ref_d = bone_dirs(ref_arm, ref_rest, ident)
    src_d = bone_dirs(src_arm, src_rest, m)
    mats = {}
    for s, r in m.items():
        sh, sd = src_d[s]
        rh, rd = ref_d[r]
        if sd.length < 1e-6 or rd.length < 1e-6:
            mats[r] = Matrix.Translation(rh - sh)
            continue
        k = rd.length / sd.length
        n = sd.normalized()
        stretch = Matrix.Identity(3) + (k - 1) * Matrix([[n.x * n.x, n.x * n.y, n.x * n.z],
                                                          [n.y * n.x, n.y * n.y, n.y * n.z],
                                                          [n.z * n.x, n.z * n.y, n.z * n.z]])
        rot = sd.rotation_difference(rd).to_matrix()
        lin = (rot @ stretch).to_4x4()
        mats[r] = Matrix.Translation(rh) @ lin @ Matrix.Translation(-sh)
        if base(r).endswith(("Foot", "ToeBase", "Toe_End")):
            sole = mats[r] @ Vector((sh.x, sh.y, ground))
            if rh.z - sole.z > 1e-4:
                k = rh.z / (rh.z - sole.z)
                sq = Matrix.Identity(4)
                sq[2][2] = k
                mats[r] = Matrix.Translation((0, 0, rh.z)) @ sq @ Matrix.Translation((0, 0, -rh.z)) @ mats[r]
    return mats


def world_coords(o):
    mw = o.matrix_world
    return [mw @ v.co for v in o.data.vertices]


def set_world(o, coords):
    for v, c in zip(o.data.vertices, coords):
        v.co = c


def conform_mesh(o, src_arm, m, mats):
    vg = {g.index: g.name for g in o.vertex_groups}
    bones = src_arm.data.bones
    gmap = {}
    for gi, gn in vg.items():
        if gn in bones:
            gmap[gi] = nearest_mapped(bones[gn], m)
    keys = o.data.shape_keys.key_blocks if o.data.shape_keys else []
    mw = o.matrix_world
    per_v = []
    for v in o.data.vertices:
        ws = {}
        for g in v.groups:
            if g.group in gmap and g.weight > 0:
                ws[gmap[g.group]] = ws.get(gmap[g.group], 0) + g.weight
        tot = sum(ws.values())
        per_v.append([(r, w / tot) for r, w in ws.items()] if tot > 0 else [(P + "Hips", 1.0)])

    def move(co):
        return sum(((mats.get(r, Matrix.Identity(4)) @ co) * w for r, w in per_v_i), Vector())
    out = []
    for i, v in enumerate(o.data.vertices):
        per_v_i = per_v[i]
        out.append(move(mw @ v.co))
    for c in out:                  # nothing under the floor (the soles' last few mm)
        c.z = max(c.z, 0.0)
    key_out = []
    for kb in keys:
        ko = []
        for i, d in enumerate(kb.data):
            per_v_i = per_v[i]
            ko.append(move(mw @ d.co))
        key_out.append(ko)
    return out, key_out, gmap


def unparent_keep(o, coords, key_coords):
    o.parent = None
    o.matrix_world = Matrix.Identity(4)
    set_world(o, coords)
    if o.data.shape_keys:
        for kb, ko in zip(o.data.shape_keys.key_blocks, key_coords):
            for d, c in zip(kb.data, ko):
                d.co = c


def rename_groups(o, gmap, ref_arm):
    """own weights: the source groups summed into their reference bones; the end bones' into their parents"""
    vg = o.vertex_groups
    data = {}
    for v in o.data.vertices:
        for g in v.groups:
            r = gmap.get(g.group)
            if r is None or g.weight <= 0:
                continue
            rb = ref_arm.data.bones[r]
            while rb.parent and (rb.name.endswith("_End") or rb.name[-1] == "4" and "Hand" in rb.name):
                rb = rb.parent
            data.setdefault(rb.name, {}).setdefault(v.index, 0.0)
            data[rb.name][v.index] += g.weight
    for g in list(vg):
        vg.remove(g)
    for name, ws in data.items():
        g = vg.new(name=name)
        for vi, w in ws.items():
            g.add([vi], min(1.0, w), 'REPLACE')


def weights_from_body(o, body):
    for g in list(o.vertex_groups):
        o.vertex_groups.remove(g)
    for g in body.vertex_groups:
        o.vertex_groups.new(name=g.name)
    dt = o.modifiers.new("DT", 'DATA_TRANSFER')
    dt.object = body
    dt.use_vert_data = True
    dt.data_types_verts = {'VGROUP_WEIGHTS'}
    dt.vert_mapping = 'POLYINTERP_NEAREST'
    dt.layers_vgroup_select_src = 'ALL'
    dt.layers_vgroup_select_dst = 'NAME'
    bpy.context.view_layer.objects.active = o
    bpy.ops.object.modifier_apply(modifier=dt.name)


def keys_from_body(o, body):
    """the body's shape keys onto the mesh: Surface Deform bound to the body's basis, one key per body key"""
    bkeys = [k for k in body.data.shape_keys.key_blocks[1:]]
    for k in bkeys:
        k.value = 0.0
    arm_mods = [md for md in body.modifiers if md.type == 'ARMATURE']
    for md in arm_mods:
        md.show_viewport = False
    sd = o.modifiers.new("SD", 'SURFACE_DEFORM')
    sd.target = body
    bpy.context.view_layer.objects.active = o
    bpy.ops.object.surfacedeform_bind(modifier=sd.name)
    if not o.data.shape_keys:
        o.shape_key_add(name="Basis")
    for k in bkeys:
        k.value = 1.0
        dg = bpy.context.evaluated_depsgraph_get()
        ev = o.evaluated_get(dg)
        kb = o.shape_key_add(name=k.name, from_mix=False)
        for i, v in enumerate(ev.data.vertices):
            kb.data[i].co = v.co
        kb.value = 0.0
        k.value = 0.0
    o.modifiers.remove(sd)
    for md in arm_mods:
        md.show_viewport = True
    return [k.name for k in bkeys]


def textures(objs, out_dir, asset_id):
    tex_dir = os.path.join(out_dir, "Textures")
    done = {}
    for o in objs:
        for mat in o.data.materials:
            if not mat or not mat.use_nodes:
                continue
            mat.name = asset_id if len(o.data.materials) == 1 else mat.name
            for n in mat.node_tree.nodes:
                if n.type != 'TEX_IMAGE' or not n.image:
                    continue
                img = n.image
                if img.name in done:
                    n.image = done[img.name]
                    continue
                nm = (img.name + " " + (img.filepath or "")).lower()
                kind = next((k for k in ("normal", "roughness", "metallic", "emission", "occlusion")
                             if k in nm), "basecolor")
                w, h = img.size
                if w == 0:
                    continue
                if max(w, h) > MAX_TEX:
                    f = MAX_TEX / max(w, h)
                    img.scale(int(w * f), int(h * f))
                os.makedirs(tex_dir, exist_ok=True)
                name = f"{asset_id}_{kind}"
                while any(os.path.basename(d.filepath_raw) == name + ".png" for d in done.values()):
                    name += "_2"
                dst = os.path.join(tex_dir, name + ".png")
                img.filepath_raw = dst
                img.file_format = 'PNG'
                img.save()
                img.filepath = dst
                done[img.name] = img
    return sorted(os.path.basename(i.filepath_raw) for i in done.values())


def export(path, objs):
    for o in bpy.data.objects:
        o.select_set(o in objs)
    bpy.ops.export_scene.fbx(
        filepath=path, use_selection=True, object_types={'ARMATURE', 'MESH'}, add_leaf_bones=False,
        bake_anim=False, use_mesh_modifiers=False, mesh_smooth_type='FACE', path_mode='RELATIVE',
        embed_textures=False)


def export_glb(path, objs):
    """the same model as GLB (textures inside, JPEG), for a browser viewer"""
    for o in bpy.data.objects:
        o.select_set(o in objs)
    bpy.ops.export_scene.gltf(filepath=path, export_format='GLB', use_selection=True, export_skins=True,
                              export_morph=True, export_animations=False, export_yup=True,
                              export_image_format='JPEG', export_jpeg_quality=88)


def skeleton_id(arm):
    """stable id of the bone set: mixamo65, plus "+tail" when the rig has a tail (ratfolk)"""
    return "mixamo65" + ("+tail" if any(b.name.endswith("Tail1") for b in arm.data.bones) else "")


def preview(path, src_objs, src_arm, meshes, ref_arm, body, height):
    """source | fitted | fitted over the reference body (ghost) | fitted in a test pose"""
    sc = bpy.context.scene
    step = height * 1.1
    for o in src_objs:
        if o.type == 'MESH':
            o.hide_render = False
    if src_arm:
        src_arm.location.x -= step
    for o in meshes:
        o.hide_render = False
    # copies: over the body, and posed on a second skeleton
    ghost = body.copy()
    ghost.data = body.data.copy()
    sc.collection.objects.link(ghost)
    for md in list(ghost.modifiers):
        ghost.modifiers.remove(md)
    ghost.parent = None
    ghost.location.x = step
    gm = bpy.data.materials.new("ghost")
    gm.diffuse_color = (0.2, 0.5, 1.0, 0.35)
    ghost.data.materials.clear()
    ghost.data.materials.append(gm)
    body.hide_render = True
    over = []
    arm2 = ref_arm.copy()
    arm2.data = ref_arm.data.copy()
    sc.collection.objects.link(arm2)
    arm2.location.x = 2 * step
    for o in meshes:
        c = o.copy()
        c.data = o.data
        sc.collection.objects.link(c)
        c.location.x = step
        over.append(c)
        p = o.copy()
        p.data = o.data
        sc.collection.objects.link(p)
        p.parent = arm2
        p.matrix_parent_inverse = Matrix.Identity(4)
        for md in p.modifiers:
            if md.type == 'ARMATURE':
                md.object = arm2
    pb = arm2.pose.bones
    # arms down and forward, one knee up: rotations in world terms through the bones' own axes
    def turn(name, axis, ang):
        b = pb[name]
        mw = arm2.matrix_world @ b.bone.matrix_local
        local = (mw.to_3x3().inverted() @ Vector(axis)).normalized()
        b.rotation_mode = 'QUATERNION'
        from mathutils import Quaternion
        b.rotation_quaternion = Quaternion(local, ang) @ b.rotation_quaternion
    turn(P + "LeftArm", (0, 1, 0), 1.1)
    turn(P + "RightArm", (0, 1, 0), -1.1)
    turn(P + "LeftForeArm", (0, 0, 1), 0.9)
    turn(P + "RightUpLeg", (1, 0, 0), 1.0)
    turn(P + "RightLeg", (1, 0, 0), -1.4)
    turn(P + "Spine1", (0, 0, 1), 0.35)
    sc.render.engine = 'BLENDER_WORKBENCH'
    sc.display.shading.light = 'STUDIO'
    sc.display.shading.color_type = 'MATERIAL'
    sc.display.shading.show_xray = False
    cam_d = bpy.data.cameras.new("cam")
    cam_d.type = 'ORTHO'
    cam_d.ortho_scale = step * 4.3
    cam = bpy.data.objects.new("cam", cam_d)
    sc.collection.objects.link(cam)
    sc.camera = cam
    cam.location = (step * 0.5, -20, height * 0.55)
    cam.rotation_euler = (1.5708, 0, 0)
    sc.render.resolution_x = 2400
    sc.render.resolution_y = int(2400 * height * 1.25 / (step * 4.3))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    sc.render.filepath = path
    bpy.ops.render.render(write_still=True)


def main():
    a = sys.argv[sys.argv.index("--") + 1:]
    src, rtype, out_dir, asset_id = a[:4]
    src, out_dir = os.path.abspath(src), os.path.abspath(out_dir)
    weights = a[a.index("--weights") + 1] if "--weights" in a else None
    bpy.ops.wm.read_factory_settings(use_empty=True)
    rigs = rigs_dir(a)
    print(f"RESULT   rigs: {rigs}")
    ref_arm, body = load_rig(rigs, rtype)
    ref_rest = rest(ref_arm)
    height = max((body.matrix_world @ v.co).z for v in body.data.vertices)
    new = import_any(src)
    src_arm = next((o for o in new if o.type == 'ARMATURE'), None)
    meshes = [o for o in new if o.type == 'MESH']
    for act in list(bpy.data.actions):
        bpy.data.actions.remove(act)
    report = {}
    if src_arm:
        weights = weights or "own"
        src_arm.animation_data_clear()
        src_arm.data.pose_position = 'REST'
        if "--keep-shape" in a:
            # only the size: scale the source to the reference height, its proportions stay
            zs = [c.z for o in meshes for c in world_coords(o)]
            f = height / (max(zs) - min(zs))
            src_arm.scale = [s * f for s in src_arm.scale]
            bpy.context.view_layer.update()
        src_rest = rest(src_arm)
        m = map_bones(src_arm, ref_arm, ref_rest, src_rest)
        if "--keep-shape" in a:
            mats = {r: Matrix.Identity(4) for r in m.values()}
        else:
            ground = min(c.z for o in meshes for c in world_coords(o))
            mats = fit_matrices(src_arm, ref_arm, m, src_rest, ref_rest, ground)
        report["matched"] = len(set(m.values()))
        report["unmatched source bones"] = [b.name for b in src_arm.data.bones if b.name not in m]
        report["reference bones with no source"] = [b.name for b in ref_arm.data.bones
                                                     if b.name not in m.values() and not b.name.endswith("_End")]
        fitted = {}
        for o in meshes:
            coords, kc, gmap = conform_mesh(o, src_arm, m, mats)
            fitted[o.name] = (coords, kc, gmap)
        src_copy = []
        if "--preview" in a:
            # keep an untouched copy of the source for the sheet
            for o in meshes:
                c = o.copy()
                c.data = o.data.copy()
                bpy.context.collection.objects.link(c)
                src_copy.append(c)
        for o in meshes:
            coords, kc, gmap = fitted[o.name]
            for md in list(o.modifiers):
                if md.type == 'ARMATURE':
                    o.modifiers.remove(md)
            unparent_keep(o, coords, kc)
            if weights == "own":
                rename_groups(o, gmap, ref_arm)
    else:
        weights = weights or "body"
        src_copy = []
        for o in meshes:
            coords = world_coords(o)
            o.parent = None
            o.matrix_world = Matrix.Identity(4)
            set_world(o, coords)
    if weights == "body":
        for o in meshes:
            weights_from_body(o, body)
    keys = []
    if "--keys" in a:
        for o in meshes:
            keys = keys_from_body(o, body)
    for o in meshes:
        for md in list(o.modifiers):
            o.modifiers.remove(md)
        md = o.modifiers.new("Armature", 'ARMATURE')
        md.object = ref_arm
        o.parent = ref_arm
        o.matrix_parent_inverse = ref_arm.matrix_world.inverted()
    texs = textures(meshes, out_dir, asset_id)
    if len(meshes) == 1:
        meshes[0].name = meshes[0].data.name = asset_id
    os.makedirs(out_dir, exist_ok=True)
    export(os.path.join(out_dir, asset_id + ".fbx"), [ref_arm] + meshes)
    tris = 0
    for o in meshes:
        o.data.calc_loop_triangles()
        tris += len(o.data.loop_triangles)
    zs = [c.z for o in meshes for c in world_coords(o)]
    if "--preview" in a:
        if src_arm:
            for o in src_copy:
                o.parent = src_arm
            src_arm.data.pose_position = 'REST'
        preview(os.path.join(out_dir, "Previews", asset_id + "_conform.png"), src_copy, src_arm, meshes,
                ref_arm, body, height)
    export_glb(os.path.join(out_dir, asset_id + ".glb"), [ref_arm] + meshes)
    info = {"schema": "artpipeline.rig/1", "id": asset_id, "body_type": rtype, "skeleton": skeleton_id(ref_arm),
            "height_m": round(max(zs) - min(zs), 3), "bones_found": report.get("matched"),
            "bones_missing": report.get("reference bones with no source", []),
            "source_bones_unmatched": report.get("unmatched source bones", []), "tris": tris,
            "shape_keys": keys, "weights": weights, "source": os.path.basename(src),
            "files": {"fbx": asset_id + ".fbx", "glb": asset_id + ".glb", "textures": texs,
                      "preview": f"Previews/{asset_id}_conform.png" if "--preview" in a else None},
            "tool": "Blender/conform_to_rig.py"}
    with open(os.path.join(out_dir, asset_id + ".rig.json"), "w", encoding="utf-8") as fh:
        json.dump(info, fh, ensure_ascii=False, indent=2)
    print(f"RESULT {asset_id} -> {rtype}: weights {weights}, tris {tris}, height {max(zs) - min(zs):.3f} "
          f"(feet {min(zs):.3f}), keys {keys}, textures {texs}")
    for k, v in report.items():
        print(f"RESULT   {k}: {v}")


main()
