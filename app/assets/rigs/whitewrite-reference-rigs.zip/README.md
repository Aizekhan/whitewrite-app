# Еталонні скелети / Reference rigs

*Українська нижче, English further down.*

## Українською

Вісім еталонних скелетів із базовими тілами й скрипт, який підганяє вашого персонажа чи броню під еталон.
Усе спорядження, зроблене на еталоні, сідає на будь-якого персонажа цього типу тіла: у них однакові назви
кісток, ієрархія, rest-поза й довжини кісток.

### Що в архіві
```
README.md
Blender/conform_to_rig.py      скрипт підгонки
Rigs/RIGS.md                   докладний опис еталонів
Rigs/rigs_front.png            усі типи поруч
Rigs/<тип>/<тип>.fbx           скелет + базове тіло (для Unity)
Rigs/<тип>/<тип>.glb           те саме для перегляду
Rigs/<тип>/<тип>.blend         першоджерело (його читає скрипт)
Rigs/<тип>/<тип>.rig.json      паспорт еталона (schema artpipeline.rig/1)
Rigs/<тип>/<тип>_bones.tsv     rest-поза кожної кістки
```

| Тип (id) | Зріст | Скелет (id) |
|---|---|---|
| `human_male` | 1,80 м | `mixamo65` |
| `human_female` | 1,70 м | `mixamo65` |
| `goblin` | 1,40 м | `mixamo65` |
| `dwarf` | 1,35 м | `mixamo65` |
| `ogre` | 2,50 м | `mixamo65` |
| `elf` | 1,85 м | `mixamo65` |
| `orc` | 1,95 м | `mixamo65` |
| `ratfolk` | 1,45 м | `mixamo65+tail` (ще `Tail1`–`Tail6`) |

Скелет: 65 кісток з назвами Mixamo (`mixamorig:Hips` … пальці 1–4), T-поза, метри, ступні на землі,
обличчям на +Z у Unity. Базове тіло: 12 тис. трикутників, ваги на скелеті, shape keys `Thin`, `Heavy`, `Muscular`.

### Що потрібно
**Blender 4.5 LTS** (https://www.blender.org/download/lts/). Скрипт працює без вікна (headless).

### Як підігнати модель
Розпакуйте архів, відкрийте PowerShell у розпакованій теці:
```powershell
& "C:\Program Files\Blender Foundation\Blender 4.5\blender.exe" -b -P Blender\conform_to_rig.py -- `
    "D:\Models\my_hero.fbx" human_male "D:\Models\out\my_hero" my_hero --keys --preview
```
(шлях до `blender.exe` — ваш; портативний Blender теж підходить.)

Аргументи: `<модель.fbx|.glb> <тип> <тека виходу> <id>` і прапорці:

| Прапорець | Що робить |
|---|---|
| `--weights own` | лишити власні ваги моделі, перейменовані на кістки еталона (типово для моделі зі скелетом) |
| `--weights body` | взяти ваги з базового тіла еталона (для броні, одягу; типово для моделі без скелета) |
| `--keys` | перенести shape keys тіла (`Thin`, `Heavy`, `Muscular`) на модель, щоб вона змінювала статуру разом із тілом |
| `--keep-shape` | лише зріст і назви кісток, без підгонки пропорцій (унікальний герой; спорядження еталона на нього **не** сяде) |
| `--preview` | картинка `Previews/<id>_conform.png`: джерело, підігнана модель, поверх тіла, тестова поза |
| `--rigs <тека>` | де лежать еталони; без нього — тека `Rigs` поруч із текою скрипта |

Модель зі скелетом (Meshy, Mixamo: кістки `mixamorig:*`, T- або A-поза) підганяється під еталон: кожна кістка
лягає на еталонну, а меш іде за своїми вагами. Модель без скелета (броня, змодельована на базовому тілі) лишається
на місці й отримує ваги з тіла.

На виході в теці: `<id>.fbx` (для Unity), `<id>.glb` (для перегляду), `Textures/<id>_*.png` (до 2048 px),
`<id>.rig.json` (паспорт), з `--preview` — `Previews/<id>_conform.png`.

### Робочий процес
1. Зробіть свого персонажа або броню на еталоні: відкрийте `Rigs/<тип>/<тип>.blend` у Blender і моделюйте на
   базовому тілі, або згенеруйте персонажа (у T-позі, зі скелетом Mixamo).
2. Запустіть `conform_to_rig.py` (команда вище).
3. У Кузні персонажів WhiteWrite завантажте **FBX + GLB + прев'ю + rig.json** новою версією етапу.

### Перевірка скелета (з `rig.json`)
- **passed**: `bones_missing` порожній;
- **warning**: бракує лише кінцевих кісток (`*_End`, пальцеві `*4`; у `ratfolk` — `Tail*`, якщо в моделі немає хвоста);
- **failed**: бракує будь-якої іншої кістки.
- `skeleton` має збігатися з ригом персонажа (інакше failed), `body_type` — з його тілом (інакше warning: можливий кліпінг).

### Unity
Rig → Humanoid, Avatar → Create From This Model з `<тип>.fbx`, один Avatar на тип (персонажі й спорядження цього
типу беруть його ж). Спорядження: SkinnedMeshRenderer, кістки якого прив'язуються до кісток персонажа за назвами.
Статура: `SetBlendShapeWeight` з тими самими назвами на тілі й на кожному предметі.

---

## English

Eight reference skeletons with base bodies, and a script that fits your character or armour to a reference.
Any gear made on a reference fits every character of that body type: they share bone names, hierarchy, rest pose
and bone lengths.

### What is inside
```
README.md
Blender/conform_to_rig.py      the fitting script
Rigs/RIGS.md                   detailed notes on the rigs (Ukrainian)
Rigs/rigs_front.png            all types side by side
Rigs/<type>/<type>.fbx         skeleton + base body (for Unity)
Rigs/<type>/<type>.glb         the same, for viewing
Rigs/<type>/<type>.blend       the source of truth (the script reads it)
Rigs/<type>/<type>.rig.json    the rig's passport (schema artpipeline.rig/1)
Rigs/<type>/<type>_bones.tsv   rest pose of every bone
```

| Type (id) | Height | Skeleton (id) |
|---|---|---|
| `human_male` | 1.80 m | `mixamo65` |
| `human_female` | 1.70 m | `mixamo65` |
| `goblin` | 1.40 m | `mixamo65` |
| `dwarf` | 1.35 m | `mixamo65` |
| `ogre` | 2.50 m | `mixamo65` |
| `elf` | 1.85 m | `mixamo65` |
| `orc` | 1.95 m | `mixamo65` |
| `ratfolk` | 1.45 m | `mixamo65+tail` (plus `Tail1`–`Tail6`) |

Skeleton: 65 bones with Mixamo names (`mixamorig:Hips` … fingers 1–4), T-pose, metres, feet on the ground, facing
Unity +Z. Base body: 12k triangles, weighted to the skeleton, shape keys `Thin`, `Heavy`, `Muscular`.

### Requirements
**Blender 4.5 LTS** (https://www.blender.org/download/lts/). The script runs without a window (headless).

### Fitting a model
Unpack the archive and open PowerShell in the unpacked folder:
```powershell
& "C:\Program Files\Blender Foundation\Blender 4.5\blender.exe" -b -P Blender\conform_to_rig.py -- `
    "D:\Models\my_hero.fbx" human_male "D:\Models\out\my_hero" my_hero --keys --preview
```
(use your own path to `blender.exe`; a portable Blender works too.)

Arguments: `<model.fbx|.glb> <type> <output folder> <id>` and flags:

| Flag | What it does |
|---|---|
| `--weights own` | keep the model's own weights, renamed to the reference bones (default for a rigged model) |
| `--weights body` | take the weights from the reference body (armour, clothes; default for an unrigged model) |
| `--keys` | carry the body's shape keys (`Thin`, `Heavy`, `Muscular`) onto the model, so it changes build with the body |
| `--keep-shape` | only height and bone names, no proportion fit (a unique hero; reference gear will **not** fit it) |
| `--preview` | an image `Previews/<id>_conform.png`: source, fitted, over the body, a test pose |
| `--rigs <folder>` | where the rigs are; without it, the `Rigs` folder next to the script's folder |

A rigged model (Meshy, Mixamo: `mixamorig:*` bones, T- or A-pose) is fitted to the reference: each bone is laid
onto the reference bone and the mesh follows its own weights. An unrigged model (armour modelled on the base body)
stays where it is and gets its weights from the body.

Output folder: `<id>.fbx` (for Unity), `<id>.glb` (for viewing), `Textures/<id>_*.png` (up to 2048 px),
`<id>.rig.json` (passport), and with `--preview` `Previews/<id>_conform.png`.

### Workflow
1. Make your character or armour on a reference: open `Rigs/<type>/<type>.blend` in Blender and model on the
   base body, or generate a character (T-pose, Mixamo skeleton).
2. Run `conform_to_rig.py` (command above).
3. In the WhiteWrite Character Forge upload **FBX + GLB + preview + rig.json** as a new version of the stage.

### Skeleton check (from `rig.json`)
- **passed**: `bones_missing` is empty;
- **warning**: only end bones are missing (`*_End`, finger `*4`; for `ratfolk` also `Tail*` when the model has no tail);
- **failed**: any other bone is missing.
- `skeleton` must match the character's rig (else failed), `body_type` its body (else warning: possible clipping).

### Unity
Rig → Humanoid, Avatar → Create From This Model from `<type>.fbx`, one Avatar per type (characters and gear of that
type use the same one). Gear: a SkinnedMeshRenderer whose bones are bound to the character's bones by name.
Build: `SetBlendShapeWeight` with the same names on the body and on every piece of gear.
